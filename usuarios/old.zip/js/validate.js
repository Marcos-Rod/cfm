$().ready(function () {

    $('#register').validate({
        rules: {
            name: {
                required: true,
                minlength: 5
            },
            mail: {
                required: true,
                email: true
            },
            phone: {
                required: true,
                phoneUS: true
            }
        },
        messages: {
            name: {
                required: "Debe poner un nombre",
                minlength: "Escriba su nombre completo"
            },
            phone: {
                required: "El tel&eacute;fono es requerido",
                phoneUS: "Escriba un n&uacute;mero v&aacute;lido"
            },
            mail: {
                required: "Escriba un correo",
                email: "Escriba un correo v&aacute;lido"
            }
        }
    });

    $('#login').validate({
        rules: {
            folio: {
                required: true,
                minlength: 5,
                maxlength: 5
            },
            mail: {
                required: true,
                email: true
            }
        },
        messages: {
            folio: {
                required: "Debe escribir su folio",
                minlength: "Escriba correctamente el folio (5 d&iacute;gitos)",
                maxlength: "Escriba correctamente el folio (5 d&iacute;gitos)"
            },
            mail: {
                required: "Escriba su correo",
                email: "Escriba un correo v&aacute;lido"
            }
        }
    });

});