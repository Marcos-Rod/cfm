$().ready(function(){
    $('#credito_tipo').change(function(){
        let seleccion= $(this).children("option:selected").attr('id');
       switch (seleccion) {
        case '1':
            $("#documentacion").load('./template/inputs/mejoravit.php');
            break;
        case '2':
            $("#documentacion").load('./template/inputs/c_pensionados.php');
            break;
        case '3':
            $("#documentacion").load('./template/inputs/c_renova.php');
            break;
        case '4':
            $("#documentacion").load('./template/inputs/c_pyme.php');
            break;
        case '5':
            $("#documentacion").load('./template/inputs/c_nomina.php');
            break;
        case '6':
            $("#documentacion").load('./template/inputs/c_tradicional.php');
            break;
        case '7':
            $("#documentacion").load('./template/inputs/c_fovissste_infonavit_individual.php');
            break;
        case '8':
            $("#documentacion").load('./template/inputs/c_mancomunado.php');
            break;
        case '9':
            $("#documentacion").load('./template/inputs/c_hipotecario_conyugal_fovissste_infonavit.php');
            break;
       }
    });
});