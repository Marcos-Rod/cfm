<div class="contenido my-5 pb-4">
    <div class="container">
        <div class="row">

            <?
            if (file_exists(URL_SERVIDOR . "/template/forms/" . strtolower($url_form) . ".php"))
                include_once(URL_SERVIDOR  . "/template/forms/" . strtolower($url_form) . ".php");
            else
                echo '<div class="text-center">
                        <h2>P&aacute;gina no encontrada :(</h2>
                        <p>Lo sentimos, esta p&aacute;gina no existe</p>
                    </div>';
            ?>

        </div>
    </div>
</div>
