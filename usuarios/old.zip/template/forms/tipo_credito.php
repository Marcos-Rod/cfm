<pre>
<?
/* print_r($_POST);
print_r($_FILES); */
?>
</pre>
<h2 class="text-center">Tipo de credito</h2>
<div class="offset-md-3 col-md-6 card-form shadow p-4 rounded overflow-hidden">
    <form action="./template/forms/tipo_credito.php" method="post" enctype="multipart/form-data">
        <div class="form-group mb-3">
            <label for="credito_tipo">Selecciona el tipo de cr&eacute;dito</label>
            <select name="credito_tipo" id="credito_tipo" class="form-select">
                <option> -- Selecciona una opci&oacute;n --</option>
                <option value="MEJORAVIT" id="1">MEJORAVIT</option>
                <option value="C. PARA PENSIONADOS" id="2">C. PARA PENSIONADOS</option>
                <option value="C. RENOVA" id="3">C. RENOVA</option>
                <option value="C. PYME" id="4">C. PYME</option>
                <option value="C. NÓMINA" id="5">C. NÓMINA</option>
                <option value="C. TRADICIONAL" id="6">C. TRADICIONAL</option>
                <option value="C. FOVISSSTE - INFONAVIT INDIVIDUAL" id="7">C. FOVISSSTE - INFONAVIT INDIVIDUAL</option>
                <option value="C. MANCOMUNADO" id="8">C. MANCOMUNADO</option>
                <option value="C. HIPOTECARIO CONYUGAL FOVISSSTE - INFONAVI" id="9">C. HIPOTECARIO CONYUGAL FOVISSSTE - INFONAVIT</option>
            </select>
        </div>
        <div class="form-group" id="documentacion"></div>
        <div class="form-group float-end mt-3">
            <input type="submit" value="Continuar >>" class="btn btn-form">
        </div>
    </form>
</div>