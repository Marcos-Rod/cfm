<div class="form-group mb-3" data-aos="fade-right">
    <label for="identificacion_oficial">Identidicaci&oacute;n oficial</label>
    <input type="file" name="identificacion_oficial" id="identificacion_oficial" class="form-control">
</div>

<div class="form-group mb-3" data-aos="fade-right" data-aos-delay="50">
    <label for="acta_matrimonio">Acta de matrimonio</label>
    <input type="file" name="acta_matrimonio" id="acta_matrimonio" class="form-control">
</div>

<div class="form-group mb-3" data-aos="fade-right" data-aos-delay="150">
    <label for="comp_domicilio">Comprobante de domicilio</label>
    <input type="file" name="comp_domicilio" id="comp_domicilio" class="form-control">
</div>

<div class="form-group mb-3" data-aos="fade-right" data-aos-delay="250">
    <label for="curp">CURP</label>
    <input type="file" name="curp" id="curp" class="form-control">
</div>

<div class="form-group mb-3" data-aos="fade-right" data-aos-delay="300">
    <label for="precalificacion_tradicional">Precalificaci&oacute;n tradicional (en caso de tener)</label>
    <input type="file" name="precalificacion_tradicional" id="precalificacion_tradicional" class="form-control">
</div>