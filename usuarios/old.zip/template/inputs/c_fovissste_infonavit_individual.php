<div class="w-100 mt-3" data-aos="fade-right">
    <label>¿Es derechohabiente activo en ambas instituciones crediticias?</label>
</div>
<div class="mb-3 form-check form-check-inline" data-aos="fade-right">
    <input class="form-check-input" type="radio" name="derechohabiente" id="derechohabiente" value="Si" checked>
    <label class="form-check-label" for="derechohabiente">Si</label>
</div>
<div class="mb-3 form-check form-check-inline" data-aos="fade-right">
    <input class="form-check-input" type="radio" name="derechohabiente" id="derechohabiente2" value="No">
    <label class="form-check-label" for="derechohabiente2">No</label>
</div>

<div class="w-100 mt-3" data-aos="fade-right">
    <label>¿Se encuentra en proceso hipotecario con FOVISSSTE?</label>
</div>
<div class="mb-3 form-check form-check-inline" data-aos="fade-right">
    <input class="form-check-input" type="radio" name="proceso_hipotecario" id="proceso_hipotecario" value="Si">
    <label class="form-check-label" for="proceso_hipotecario">Si</label>
</div>
<div class="mb-3 form-check form-check-inline" data-aos="fade-right">
    <input class="form-check-input" type="radio" name="proceso_hipotecario" id="proceso_hipotecario2" value="No" checked>
    <label class="form-check-label" for="proceso_hipotecario2">No</label>
</div>

<div class="form-group mb-3" data-aos="fade-right" data-aos-delay="50">
    <label for="solicitud_cfm">Solicitud en Cr&eacute;dito Financiera Mexicana</label>
    <input type="file" name="solicitud_cfm" id="solicitud_cfm" class="form-control">
</div>