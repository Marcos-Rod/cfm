<div class="mb-3">
    <label>Es necesario que ambos sean beneficiarios del sistema de puntaje FOVISSSTE para ejercer su cr&eacute;dito tradicional.</label>
    
</div>