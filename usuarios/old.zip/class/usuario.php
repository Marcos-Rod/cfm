<?
include_once(URL_SERVIDOR . '/class/db.php');
include_once(URL_SERVIDOR . '/class/generales.php');

class usuario
{
    public $user = "";
    protected $password = "";
    public $folio = "";

    function __construct()
    {
        $this->db = new db();
        $this->generales = new generales();
    }

    public function create($request)
    {
        if (!is_array($request) || empty($request["user"] || empty($request["password"])))
            return false;

        $sql_select = sprintf(" SELECT 
                    correo 
                FROM
                    users 
                WHERE
                    correo = '%s'",
            $request['mail']
        );

        if($arr_select = $this->db->db_query($sql_select, 1)){
            $existe = 3;
            return $existe;
        }

        $folio = $this->crea_folio();

        $sql = sprintf(
            "INSERT INTO
                    users (nombre, correo, telefono, folio, create_at)
                VALUES
                    ('%s', '%s', '%s', '%d', '%s')
                ",
            $this->db->db_limpia_cadena_sql($request['name']),
            $this->db->db_limpia_cadena_sql($request['mail']),
            $this->db->db_limpia_cadena_sql($request['phone']),
            $folio,
            $this->generales->hoy()
        );


        if (!$response = $this->db->db_query($sql, 2))
            return false;

        return $folio;
    }

    public function crea_folio()
    {
        $cont = "";

        $sql = sprintf("SELECT MAX(folio) as folio FROM users");
        if (!$response = $this->db->db_query($sql, 1))
            return false;

        $last_folio = array_values($response[0]);
        if ($last_folio[0] == "") {
            $new_folio = str_pad(101, 5, '0', STR_PAD_LEFT);
        } else {
            $last_folio = intval($last_folio[0]);

            $new_folio = $last_folio++;
            $new_folio = str_pad($last_folio, 5, '0', STR_PAD_LEFT);
        }


        return $new_folio;
    }
    public function login($request = ""){
        if(!is_array($request) || empty($request['mail']) || empty($request['folio']))
            return false;
        
        $sql = sprintf("SELECT
                u.id,
                u.nombre,
                u.correo,
                u.telefono,
                u.folio
            FROM
                users AS u
            WHERE
                u.correo = '%s'
            AND
                u.folio = '%d'
            ",
            $this->db->db_limpia_cadena_sql($request['mail']),
            intval($request['folio'])
        );

        if(!$response = $this->db->db_query($sql, 1))
        return false;
        
        return $response;
    }
}
